# rename

This is a command tool as an alternative to PowerRename from PowerToys. Runs in terminal and support mouse operation.

Here is a quick example: 

![](example/example.gif)

## requirements

depends on python and `textual`

## install

```
git clone https://github.com/GJCav/pyrename.git
cd pyrename
pip3 install -r requirements.txt
```

## LICENSE

```
                    GNU GENERAL PUBLIC LICENSE
                       Version 3, 29 June 2007

 Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/>
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.
```